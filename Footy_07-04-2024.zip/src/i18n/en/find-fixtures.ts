export default {
	intro:
		'You have not selected a team yet. Here you can search for a team to look at their list fixtures.',
	title: 'Find fixtures',
};
