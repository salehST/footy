export default {
	back: 'Back',
	cancel: 'Cancel',
	close: 'Close',
	done: 'Done',
	edit: 'Edit',
	save: 'Save',
};
