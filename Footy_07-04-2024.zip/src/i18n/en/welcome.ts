export default {
	instruction: 'To continue please login or sign up.',
	introduction:
		'Welcome to the Footy App. Footy is the fast-growing soccer league on weekday evenings. Through this App joining Footy is going to be more fun and even easier. Work Hard. Play Footy!',
};
