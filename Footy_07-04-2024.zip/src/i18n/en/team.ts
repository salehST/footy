export default {
	all_time_record: 'All time record',
	captain: 'Captain',
	founded: 'Founded',
	recent_form: 'Recent form',
	vice_captain: 'Vice Captain',
};
