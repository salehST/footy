export default {
	empty_message: 'This league does not have standings.',
	no_awards_to_show: 'No awards to show yet',
	select_league: 'Select league',
};
