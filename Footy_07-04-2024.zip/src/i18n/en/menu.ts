export default {
	change_language: 'Change language',
	find_fixtures: 'Find fixtures',
	my_profile: 'My profile',
	log_out: 'Log out',
	profile: 'Profile',
	finals: 'Finals',
};
