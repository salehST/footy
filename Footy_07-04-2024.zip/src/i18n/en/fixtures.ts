export default {
	choose_team: 'Choose team',
	match_notification: 'Match Notification',
	my_teams: 'My teams',
	other_teams: 'Also',
	postponed: 'Postponed',
	select_team: 'Select Team',
	no_results_to_show: 'No results to show',
	no_fixtures: 'No Fixtures to show',
};
