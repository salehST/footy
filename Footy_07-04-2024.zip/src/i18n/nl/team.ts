export default {
	all_time_record: 'Statistieken',
	captain: 'Aanvoerder',
	founded: 'Opgericht',
	recent_form: 'Recente vorm',
	vice_captain: 'Vice-aanvoerder',
};
