export default {
	change_language: 'Wijzig taal',
	find_fixtures: 'Vind wedstrijden',
	my_profile: 'Mijn profiel',
	log_out: 'Uitloggen',
	profile: 'Profiel',
	finals: 'Finale',
};
