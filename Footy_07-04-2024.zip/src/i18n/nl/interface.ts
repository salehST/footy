export default {
	back: 'Terug',
	cancel: 'Annuleren',
	close: 'Sluit',
	done: 'Klaar',
	edit: 'Wijzigen',
	save: 'Opslaan',
};
