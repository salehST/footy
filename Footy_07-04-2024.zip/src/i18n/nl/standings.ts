export default {
	empty_message: 'Deze competitie heeft geen standen.',
	no_awards_to_show: 'Nog geen prijzen om te laten zien',
	select_league: 'Selecteer een Competitie',
};
