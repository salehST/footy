export default {
	intro:
		'Je hebt nog geen team geselecteerd. Hier kun je op teams zoeken om hun speelschema in te zien.',
	title: "Vind speelschema's",
};
