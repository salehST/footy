export default {
	next_fixtures: 'Je komende programma',
	recent_results: 'Recente uitslagen',
	no_team_message:
		'Het lijkt erop dat je nog geen lid bent van een team. Zoek een team, sluit je aan bij een bestaand team of creeer een nieuw team.',
	join_team_message: 'Zoek je team en sluit je bij hen aan om toegang te krijgen tot het clubhuis!',
	create_team_button: 'Maak nieuw team',
	join_team_button: 'Sluit me aan',
	find_team: 'Vind jouw team',
	team_full_message: 'Dit team zit al vol. Selecteer alsjeblieft een ander team.',
};
