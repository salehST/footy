export default {
	choose_team: 'Kies team',
	match_notification: 'Melding',
	my_teams: 'Mijn teams',
	other_teams: 'Andere teams',
	postponed: 'Uitgesteld',
	select_team: 'Selecteer een Team',
	no_results_to_show: 'Geen resultaten te zien',
	no_fixtures: 'Geen resultaten te zien',
};
