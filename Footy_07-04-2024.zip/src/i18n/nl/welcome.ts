export default {
	instruction: 'Log in of meld je aan om door te gaan.',
	introduction:
		'Welkom bij de Footy App. Footy is de snel groeiende voetbalcompetitie op doordeweekse avonden. Via deze App wordt meedoen met Footy nog leuker en makkelijker. Work Hard. Play Footy!',
};
