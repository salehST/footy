declare module '*.gql' {
	const content: any;
	export default content;
}

declare module 'body-scroll-lock';
